package ajedrez;

public enum Color {
	BLANCO, NEGRO
}
