package com.example.application.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FilmShortDTO {

	public FilmShortDTO() {
	}

}
