package com.example.domains.entities;

public interface CategoryService {

}
